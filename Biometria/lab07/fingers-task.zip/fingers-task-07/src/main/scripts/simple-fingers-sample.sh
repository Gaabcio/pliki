#!/bin/sh

java -jar simple-fingers-sample.jar
