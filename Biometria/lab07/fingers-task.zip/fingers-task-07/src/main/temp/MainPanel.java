package com.neurotec.samples;

import com.neurotec.biometrics.NFinger;
import com.neurotec.biometrics.NSubject;
import com.neurotec.biometrics.swing.NFingerView;
import com.neurotec.swing.NViewZoomSlider;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MainPanel extends BasePanel {
    private static final long serialVersionUID = 1L;

    private DefaultTableModel tableModel;
    private JButton btnIdentify;
    private JLabel lblDirPath;
    private JLabel lblTemplatePath;

    private NFingerView fingerViewLeft;
    private NFingerView fingerViewRight;

    // Szablony bazowe oraz szablon wybrany do identyfikacji
    private final ArrayList<File> templateFiles;
    private File templateFileToIdentify;

    private boolean templateFilesSelected = false;       // czy wybrano folder z bazą szablonów?
    private boolean templateToIdentifySelected = false;  // czy wybrano szablon do identyfikacji?
    private int highlightIndex = -1;                     // indeks zaznaczonego wiersa

    static {
        try {
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public MainPanel() {
        super();
        // Lista wymaganych komponentów SDK
        requiredLicenses = new ArrayList<>();
        requiredLicenses.add("Biometrics.FingerMatching"); // Dopasowywanie szablonów
//        requiredLicenses.add("Images.WSQ");                // Wyświetlanie grafiki

        // Lista opcjonalnych komponentów - jest pusta
        optionalLicenses = new ArrayList<>();

        templateFiles = new ArrayList<>();
        initGUI();
    }

    // Inicjalizacja widoku
    protected void initGUI() {
        // Ustawiamy główny układ na BorderLayout
        this.setLayout(new BorderLayout());
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Usuwamy marginesy

        panelLicensing = new LicensingPanel(requiredLicenses, optionalLicenses);
        add(panelLicensing, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(1, 2));
        add(mainPanel); // BorderLayout.CENTER

        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));  // Użycie BoxLayout
        {
            JPanel controlPanel = new JPanel();
            controlPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            controlPanel.setMinimumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
            leftPanel.add(controlPanel);
            {
                JLabel titleLabelLeft = new JLabel("Baza szablonów");
                titleLabelLeft.setFont(new Font("Arial", Font.BOLD, 14));
                controlPanel.add(titleLabelLeft);
                controlPanel.add(Box.createVerticalStrut(5));

                JButton btnOpenFolder = new JButton("Otwórz folder");
                btnOpenFolder.addActionListener(e -> handleLoadDatabase());
                controlPanel.add(btnOpenFolder);
                controlPanel.add(Box.createVerticalStrut(5));

                lblDirPath = new JLabel("Ścieżka folderu: Brak folderu");
                lblDirPath.setFont(new Font("Arial", Font.PLAIN, 9));
                controlPanel.add(lblDirPath);
            }

            // Tworzenie tabeli do wyświetlania plików
            JPanel templatesPanel = new JPanel();
            templatesPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));  // Możesz dostosować do swoich potrzeb
            leftPanel.add(templatesPanel);
            templatesPanel.setLayout(new BorderLayout()); // Zmieniamy układ na BorderLayout
            {
                tableModel = new DefaultTableModel(new Object[]{"Pliki szablonów (rozszerzenie .tp)"}, 0);
                JTable table = new JTable(tableModel);
                table.setDefaultRenderer(Object.class, new HighlightRenderer());

                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setPreferredSize(new Dimension(400, 200));  // Ustaw preferowany rozmiar scrollpane
                templatesPanel.add(scrollPane, BorderLayout.CENTER);
            }

            // Panel z podglądem obrazu
            JPanel imagePanel = new JPanel();
            imagePanel.setBorder(BorderFactory.createTitledBorder("Szablon z najlepszym dopasowaniem"));
            imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.Y_AXIS));
            leftPanel.add(imagePanel);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
                imagePanel.add(scrollPane);
                {
                    fingerViewLeft = new NFingerView();
                    fingerViewLeft.setAutofit(true);
                    fingerViewLeft.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent ev) {
                            super.mouseClicked(ev);
                            if (ev.getButton() == MouseEvent.BUTTON3) {
                                System.out.println("Click");
                            }
                        }
                    });
                    scrollPane.setViewportView(fingerViewLeft);
                }

                NViewZoomSlider imageZoomSlider = new NViewZoomSlider();
                imageZoomSlider.setView(fingerViewLeft);
                imagePanel.add(imageZoomSlider); // Dodajemy suwak powiększenia
            }
        }


        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        {
            JPanel controlPanel = new JPanel();
            controlPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            controlPanel.setMinimumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
            rightPanel.add(controlPanel);
            {
                JLabel titleLabelRight = new JLabel("Szablon do identyfikacji");
                titleLabelRight.setFont(new Font("Arial", Font.BOLD, 14));
                controlPanel.add(titleLabelRight);
                controlPanel.add(Box.createVerticalStrut(5));

                JButton btnSelectTemplate = new JButton("Wybierz szablon");
                btnSelectTemplate.addActionListener(e -> handleSelectTemplate());
                controlPanel.add(btnSelectTemplate);
                controlPanel.add(Box.createVerticalStrut(5));

                lblTemplatePath = new JLabel("Ścieżka szablonu: Brak wybranego szablonu");
                lblTemplatePath.setFont(new Font("Arial", Font.PLAIN, 9));
                controlPanel.add(lblTemplatePath); // Dodajemy etykietę do panelu prawego
                controlPanel.add(Box.createVerticalStrut(5));

                btnIdentify = new JButton("Identyfikuj");
                btnIdentify.setEnabled(false);
                btnIdentify.addActionListener(e -> handleIdentify());
                controlPanel.add(btnIdentify);
            }

            Box.Filler filler = new Box.Filler(new Dimension(0, 0), new Dimension(0, 177), new Dimension(Integer.MAX_VALUE, 177));
            rightPanel.add(filler);

            // Panel z podglądem obrazu
            JPanel imagePanel = new JPanel();
            imagePanel.setBorder(BorderFactory.createTitledBorder("Szablon do identyfikacji"));
            imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.Y_AXIS));
            rightPanel.add(imagePanel);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
                imagePanel.add(scrollPane);
                {
                    fingerViewRight = new NFingerView();
                    fingerViewRight.setAutofit(true);
                    fingerViewRight.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent ev) {
                            super.mouseClicked(ev);
                            if (ev.getButton() == MouseEvent.BUTTON3) {
                                System.out.println("Click");
                            }
                        }
                    });
                    scrollPane.setViewportView(fingerViewRight);
                }

                NViewZoomSlider imageZoomSlider = new NViewZoomSlider();
                imageZoomSlider.setView(fingerViewRight);
                imagePanel.add(imageZoomSlider);
            }
        }


        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        setPreferredSize(new Dimension(1200, 900));
    }

    //region utils
    private void handleLoadDatabase() {
        /*
          Funckja prosi uzytkownika o wybranie folderu i aktualizuje tabelę o pliki szablonów.
         */
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Wybierz folder");
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFolder = fileChooser.getSelectedFile();
            File[] tpFiles = selectedFolder.listFiles((dir, name) -> name.endsWith(".tp"));

            if (tpFiles != null) {
                // Wyczyszczenie tabeli
                templateFiles.clear();
                tableModel.setRowCount(0);

                // Zaktualizowanie tableli
                for (File tpFile : tpFiles) {
                    templateFiles.add(tpFile);
                    tableModel.addRow(new Object[]{tpFile.getName()});
                }
                templateFilesSelected = true;
                lblDirPath.setText("Ścieżka folderu: " + selectedFolder.getAbsolutePath());
            } else {
                JOptionPane.showMessageDialog(this, "Brak plików .tp w tym folderze.", "Brak plików", JOptionPane.INFORMATION_MESSAGE);
                templateFilesSelected = false;
                lblDirPath.setText("Ścieżka folderu: Brak plików .tp");
            }
            updateControls();
        }
    }

    private void handleSelectTemplate() {
        /*
        Funkcja do wyboru szablonu
         */
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Wybierz szablon");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int returnValue = fileChooser.showOpenDialog(this);

        if (returnValue == JFileChooser.APPROVE_OPTION && fileChooser.getSelectedFile().getName().endsWith(".tp")) {
            templateFileToIdentify = fileChooser.getSelectedFile();
            templateToIdentifySelected = true;
            lblTemplatePath.setText("Ścieżka szablonu: " + templateFileToIdentify.getAbsolutePath()); // Ustawienie ścieżki wybranego szablonu

            // Wyświetlenie wybranego szablonu
            setFingerView(templateFileToIdentify.getAbsolutePath(), fingerViewRight);

        } else {
            templateToIdentifySelected = false;
            lblTemplatePath.setText("Brak wybranego szablonu."); // Informacja o braku wybranego szablonu
        }
        updateControls();
    }
    // endregion utils

    private void handleIdentify() {
        /**
         * Metoda obsługująca identyfikację odcisku palca.
         *
         * Uzupełnij według następującej logiki:
         * 1. Dla każdego pliku odcisku palca w bazie szablonów (wczytanych plików .tp):
         *    - Otwórz plik z bazy i porównaj go z wybranym szablonem do identyfikacji.
         *    - Użyj odpowiednich narzędzi do dopasowania - metody verify obiektu klasy NBiometricEngine.
         *    - Sprawdź wynik dopasowania i przechowaj wynik porównania (np. status dopasowania).
         *
         * 2. Jeżeli znaleziono dopasowanie, zapisz indeks najlepszego dopasowanego pliku w bazie.
         *
         * 3. Wyświetl wynik dopasowania, np. przez:
         *    - Podświetlenie wiersza w tabeli, który odpowiada najlepszemu dopasowaniu (użyć zaimplementowanej metody `highlight(int index)`).
         *    - Wyświetlenie obrazu odcisku palca, który najlepiej pasuje do wybranego szablonu (użyć metody setFingerView).
         *
         * 4. Jeśli żadne dopasowanie nie zostało znalezione, wyświetl odpowiednią informację o błędzie lub braku dopasowania.
         * 5. Dodać do GUI element, który wyświetli jakość dopasowania.
         */
        if (templateFileToIdentify == null) {
            return;
        }
        System.out.println("Szablon do identyfikacji: " + templateFileToIdentify.getAbsolutePath());

        System.out.println("Lista dostępnych szablonów w bazie:");
        for (int i = 0; i < templateFiles.size(); i++) {
            File file = templateFiles.get(i);
            System.out.println(file.getAbsolutePath());
        }
    }

    private static void setFingerView(String path, NFingerView fingerView) {
        /**
         * Ustawia widok palca zapisanego w pliku .tp w zadanej ścieżce w widoku odcisku palca.
         * <p>
         * Ta funkcja wczytuje odcisk palca zapisany w pliku .tp z podanej ścieżki i umieszcza go
         * w widoku palca (NFingerView). Jeżeli plik nie zawiera żadnego odcisku palca lub nie można
         * go otworzyć, odpowiednie komunikaty zostaną wyświetlone.
         *
         * @param path Ścieżka do pliku zawierającego odcisk palca (.tp).
         * @param fingerView Obiekt widoku palca, do którego zostanie przypisany odcisk palca.
         */

        NSubject.FingerCollection fingers;
        try (NSubject s = NSubject.fromFile(path)) {
            fingers = s.getFingers();

            if (fingers.isEmpty()) {
                System.out.println("Szablon nie zawiera odcisków palca");
            }

            NFinger finger = fingers.get(0);
            fingerView.setFinger(finger);
        } catch (IOException e) {
            System.out.println("Nie możne otworzyć tego pliku.");
        }
    }


    private void highlight(int index) {
        /**
         * Podświetla wiesz na zadanym indeksie. Wywołanie z wartością -1 lub jakąkolwiek spoza przedziału
         * skutkuje odznaczeniem wierszy.
         * @param index - indeks wiersza do podświetlenia
         */
        highlightIndex = index;
        tableModel.fireTableDataChanged();  // Odświeżamy tabelę, aby zaktualizować widok
    }

    private class HighlightRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if (row == highlightIndex) {
                component.setBackground(Color.GREEN);
            } else {
                component.setBackground(Color.WHITE);
            }

            return component;
        }
    }

    @Override
    protected void setDefaultValues() {

    }

    @Override
    protected void updateControls() {
        // Odświeżanie stanu UI
        btnIdentify.setEnabled(templateFilesSelected && templateToIdentifySelected);
        highlight(-1);
    }

    @Override
    protected void updateFingersTools() {
        FingersTools.getInstance().getClient().reset();
    }
}
