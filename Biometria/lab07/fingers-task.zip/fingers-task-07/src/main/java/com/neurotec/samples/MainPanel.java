package com.neurotec.samples;

import com.neurotec.biometrics.*;
import com.neurotec.biometrics.client.NBiometricClient;
import com.neurotec.biometrics.swing.NFingerView;
import com.neurotec.swing.NViewZoomSlider;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;

public class MainPanel_init extends BasePanel {
    private static final long serialVersionUID = 1L;

    private DefaultTableModel tableModel;
    private JButton btnIdentify;
    private JLabel lblDirPath;
    private JLabel lblTemplatePath;

    private NFingerView fingerViewLeft;
    private NFingerView fingerViewRight;

    // Szablony bazowe oraz szablon wybrany do identyfikacji
    private final ArrayList<File> baseSubjectsFiles;
    private final ArrayList<NSubject> baseSubjects;
    private NSubject subjectToIdentify;

    private boolean templateFilesSelected = false;       // czy wybrano folder z bazą szablonów?
    private boolean templateToIdentifySelected = false;  // czy wybrano szablon do identyfikacji?
    private int highlightIndex = -1;                     // indeks zaznaczonego wiersa

    static {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public MainPanel_init() {
        super();
        // Lista wymaganych komponentów SDK
        requiredLicenses = new ArrayList<>();
        requiredLicenses.add("Biometrics.FingerMatching"); // Dopasowywanie szablonów

        // Lista opcjonalnych komponentów - jest pusta
        optionalLicenses = new ArrayList<>();
        baseSubjectsFiles = new ArrayList<>();
        baseSubjects = new ArrayList<>();
        initGUI();
    }

    // Inicjalizacja widoku
    protected void initGUI() {
        // Ustawiamy główny układ na BorderLayout
        this.setLayout(new BorderLayout());
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));  // Usuwamy marginesy

        panelLicensing = new LicensingPanel(requiredLicenses, optionalLicenses);
        add(panelLicensing, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(1, 2));
        add(mainPanel); // BorderLayout.CENTER

        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));  // Użycie BoxLayout
        {
            JPanel controlPanel = new JPanel();
            controlPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            controlPanel.setMinimumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
            leftPanel.add(controlPanel);
            {
                JLabel titleLabelLeft = new JLabel("Baza szablonów");
                titleLabelLeft.setFont(new Font("Arial", Font.BOLD, 14));
                controlPanel.add(titleLabelLeft);
                controlPanel.add(Box.createVerticalStrut(5));

                JButton btnOpenFolder = new JButton("Otwórz folder");
                btnOpenFolder.addActionListener(e -> handleLoadDatabase());
                controlPanel.add(btnOpenFolder);
                controlPanel.add(Box.createVerticalStrut(5));

                lblDirPath = new JLabel("Ścieżka folderu: Brak folderu");
                lblDirPath.setFont(new Font("Arial", Font.PLAIN, 9));
                controlPanel.add(lblDirPath);
            }

            // Tworzenie tabeli do wyświetlania plików
            JPanel templatesPanel = new JPanel();
            templatesPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));  // Możesz dostosować do swoich potrzeb
            leftPanel.add(templatesPanel);
            templatesPanel.setLayout(new BorderLayout()); // Zmieniamy układ na BorderLayout
            {
                tableModel = new DefaultTableModel(new Object[]{"Pliki szablonów (rozszerzenie .tp)", "Wynik dopasowania"}, 0);

                JTable table = new JTable(tableModel);
                table.setDefaultRenderer(Object.class, new HighlightRenderer());

                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setPreferredSize(new Dimension(400, 200));  // Ustaw preferowany rozmiar scrollpane
                templatesPanel.add(scrollPane, BorderLayout.CENTER);
            }

            // Panel z podglądem obrazu
            JPanel imagePanel = new JPanel();
            imagePanel.setBorder(BorderFactory.createTitledBorder("Szablon z najlepszym dopasowaniem"));
            imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.Y_AXIS));
            leftPanel.add(imagePanel);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
                imagePanel.add(scrollPane);
                {
                    fingerViewLeft = new NFingerView();
                    fingerViewLeft.setAutofit(true);
                    fingerViewLeft.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent ev) {
                            super.mouseClicked(ev);
                            if (ev.getButton() == MouseEvent.BUTTON3) {
                                System.out.println("Click");
                            }
                        }
                    });
                    scrollPane.setViewportView(fingerViewLeft);
                }

                NViewZoomSlider imageZoomSlider = new NViewZoomSlider();
                imageZoomSlider.setView(fingerViewLeft);
                imagePanel.add(imageZoomSlider); // Dodajemy suwak powiększenia
            }
        }


        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        {
            JPanel controlPanel = new JPanel();
            controlPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            controlPanel.setMinimumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
            rightPanel.add(controlPanel);
            {
                JLabel titleLabelRight = new JLabel("Szablon do identyfikacji");
                titleLabelRight.setFont(new Font("Arial", Font.BOLD, 14));
                controlPanel.add(titleLabelRight);
                controlPanel.add(Box.createVerticalStrut(5));

                JButton btnSelectTemplate = new JButton("Wybierz szablon");
                btnSelectTemplate.addActionListener(e -> handleSelectTemplate());
                controlPanel.add(btnSelectTemplate);
                controlPanel.add(Box.createVerticalStrut(5));

                lblTemplatePath = new JLabel("Ścieżka szablonu: Brak wybranego szablonu");
                lblTemplatePath.setFont(new Font("Arial", Font.PLAIN, 9));
                controlPanel.add(lblTemplatePath); // Dodajemy etykietę do panelu prawego
                controlPanel.add(Box.createVerticalStrut(5));

                btnIdentify = new JButton("Identyfikuj");
                btnIdentify.setEnabled(false);
                btnIdentify.addActionListener(e -> handleIdentify());
                controlPanel.add(btnIdentify);
            }

            Box.Filler filler = new Box.Filler(new Dimension(0, 0), new Dimension(0, 177), new Dimension(Integer.MAX_VALUE, 177));
            rightPanel.add(filler);

            // Panel z podglądem obrazu
            JPanel imagePanel = new JPanel();
            imagePanel.setBorder(BorderFactory.createTitledBorder("Szablon do identyfikacji"));
            imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.Y_AXIS));
            rightPanel.add(imagePanel);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
                imagePanel.add(scrollPane);
                {
                    fingerViewRight = new NFingerView();
                    fingerViewRight.setAutofit(true);
                    fingerViewRight.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent ev) {
                            super.mouseClicked(ev);
                            if (ev.getButton() == MouseEvent.BUTTON3) {
                                System.out.println("Click");
                            }
                        }
                    });
                    scrollPane.setViewportView(fingerViewRight);
                }

                NViewZoomSlider imageZoomSlider = new NViewZoomSlider();
                imageZoomSlider.setView(fingerViewRight);
                imagePanel.add(imageZoomSlider);
            }
        }


        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        setPreferredSize(new Dimension(1200, 900));
    }

    //region utils
    /**
     * Funkcja prosi uzytkownika o wybranie folderu i aktualizuje tabelę o pliki szablonów.
     */
    private void handleLoadDatabase() {

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Wybierz folder");
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFolder = fileChooser.getSelectedFile();
            File[] tpFiles = selectedFolder.listFiles((dir, name) -> name.endsWith(".tp"));

            if (tpFiles != null) {
                // Wyczyszczenie tabeli
                baseSubjects.clear();
                baseSubjectsFiles.clear();
                tableModel.setRowCount(0);

                // Zaktualizowanie tableli
                for (File tpFile : tpFiles) {
                    baseSubjectsFiles.add(tpFile);
                    tableModel.addRow(new Object[]{tpFile.getName()});
                }
                templateFilesSelected = true;
                lblDirPath.setText("Ścieżka folderu: " + selectedFolder.getAbsolutePath());
            } else {
                JOptionPane.showMessageDialog(this, "Brak plików .tp w tym folderze.", "Brak plików", JOptionPane.INFORMATION_MESSAGE);
                templateFilesSelected = false;
                lblDirPath.setText("Ścieżka folderu: Brak plików .tp");
            }
            updateControls();
        }
    }

    /**
     * Ponownie wczytuje szablony dla wszystkich plików
     */
    private void refreshDatabase() {
        baseSubjects.clear();
        for (File subjectFile : baseSubjectsFiles) {
            ArrayList<String> failedList = new ArrayList<>();
            try {
                NSubject s = NSubject.fromFile(subjectFile.getAbsolutePath());
                s.setId(subjectFile.getName());
                baseSubjects.add(s);
            } catch (IOException e) {
                failedList.add(subjectFile.getAbsolutePath());
            }

            if (!failedList.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (String path : failedList) sb.append(path).append("\n");
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(MainPanel_init.this,
                            "Nie wczytano następujacych szablonów: \n" + sb.toString(), "Error",
                            JOptionPane.WARNING_MESSAGE);
                });
            }
        }
    }

    /**
     * Wybór szablonu do identyfikacji
     */
    private void handleSelectTemplate() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Wybierz szablon");

        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int returnValue = fileChooser.showOpenDialog(this);

        if (returnValue == JFileChooser.APPROVE_OPTION && fileChooser.getSelectedFile().getName().endsWith(".tp")) {
            File file = fileChooser.getSelectedFile();
            try {
                subjectToIdentify = NSubject.fromFile(file.getAbsolutePath());
                subjectToIdentify.setId(file.getName());

                // Wyświetlenie wybranego szablonu
                setFingerView(subjectToIdentify, fingerViewRight);

                templateToIdentifySelected = true;
                lblTemplatePath.setText("Ścieżka szablonu: " + file.getAbsolutePath()); // Ustawienie ścieżki wybranego szablonu
            } catch (IOException e) {
                System.out.println(" Wczytanie szablonu " + file.getAbsolutePath() + " zakończyło się niepowodzeniem.");
            }

        } else {
            templateToIdentifySelected = false;
            lblTemplatePath.setText("Nie wybrano szablonu."); // Informacja o braku wybranego szablonu
        }
        updateControls();
    }
    // endregion utils

    /**
     * Obsługa identyfikacji
     */
    private void handleIdentify() {
        if (subjectToIdentify == null) {
            return;
        }

        refreshDatabase(); // Ponowne wczytanie osobników z wybranych plików bazy.

        System.out.println("Szablon do identyfikacji: " + subjectToIdentify.getId());

        System.out.println("Lista dostępnych szablonów w bazie:");
        for (int i = 0; i < baseSubjects.size(); i++) {
            NSubject file = baseSubjects.get(i);
            System.out.println(file.getId());
        }
    }


    /**
     * Ustawia widok palca zapisanego w pliku .tp w zadanej ścieżce w widoku odcisku palca.
     * <p>
     * Ta funkcja wczytuje odcisk palca zapisany w pliku .tp z podanej ścieżki i umieszcza go
     * w widoku palca (NFingerView). Jeżeli plik nie zawiera żadnego odcisku palca lub nie można
     * go otworzyć, odpowiednie komunikaty zostaną wyświetlone.
     *
     * @param subject Obiekt NSubject zawierający odcisk palca do wizualizacji
     * @param fingerView Obiekt widoku palca, w którym zostanie wyświetlona zawartość.
     */
    private static void setFingerView(NSubject subject, NFingerView fingerView) {
        NSubject.FingerCollection fingers;
        fingers = subject.getFingers();

        if (fingers.isEmpty()) {
            System.out.println("Szablon nie zawiera odcisków palca");
        }

        NFinger finger = fingers.get(0);
        fingerView.setFinger(finger);
    }

    // region TableCellRenderer
    /**
     * Podświetla wiesz na zadanym indeksie. Wywołanie z wartością -1 lub jakąkolwiek spoza przedziału
     * skutkuje odznaczeniem wierszy.
     * @param index - indeks wiersza do podświetlenia
     */
    private void highlight(int index) {
        highlightIndex = index;
        tableModel.fireTableDataChanged();  // Odświeżamy tabelę, aby zaktualizować widok
    }

    private class HighlightRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if (row == highlightIndex) {
                component.setBackground(Color.GREEN);
            } else {
                component.setBackground(Color.WHITE);
            }

            return component;
        }
    }
    // endregion TableCellRenderer

    @Override
    protected void setDefaultValues() {

    }

    @Override
    protected void updateControls() {
        // Odświeżanie stanu UI
        btnIdentify.setEnabled(templateFilesSelected && templateToIdentifySelected);
        highlight(-1);
    }

    @Override
    protected void updateFingersTools() {
        FingersTools.getInstance().getClient().reset();
    }
}
