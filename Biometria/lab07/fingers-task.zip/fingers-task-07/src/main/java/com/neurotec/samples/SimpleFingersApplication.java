package com.neurotec.samples;

import java.awt.BorderLayout;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import com.neurotec.licensing.NLicenseManager;
import com.neurotec.samples.util.LibraryManager;
import com.neurotec.samples.util.Utils;

public final class SimpleFingersApplication {

	// ===========================================================
	// Public static  method
	// ===========================================================

	public static void main(String[] args) {
		LibraryManager.initLibraryPath();

		//=========================================================================
		// TRIAL MODE
		//=========================================================================
		// Below code line determines whether TRIAL is enabled or not. To use purchased licenses, don't use below code line.
		// GetTrialModeFlag() method takes value from "Bin/Licenses/TrialFlag.txt" file. So to easily change mode for all our examples, modify that file.
		// Also you can just set TRUE to "TrialMode" property in code.
		//=========================================================================

		try {
			boolean trialMode = Utils.getTrialModeFlag();
			NLicenseManager.setTrialMode(trialMode);
			System.out.println("\tTrial mode: " + trialMode);
		} catch (IOException e) {
			e.printStackTrace();
		}

		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				JFrame frame = new JFrame();
				frame.setTitle("Simple Fingers Sample");
				frame.setIconImage(Utils.createIconImage("images/Logo16x16.png"));
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				BasePanel panel = new MainPanel();
				frame.add(panel, BorderLayout.CENTER);

				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);

                try {
                    obtainLicenses(panel);
                } catch (IOException e) {
					System.out.println("Obtaining error.");
                    throw new RuntimeException(e);
                }
            }
		});
	}

	public static void obtainLicenses(BasePanel panel) throws IOException {
		if (!panel.isObtained()) {
			boolean status = FingersTools.getInstance().obtainLicenses(panel.getRequiredLicenses());
			FingersTools.getInstance().obtainLicenses(panel.getOptionalLicenses());
			panel.getLicensingPanel().setRequiredComponents(panel.getRequiredLicenses());
			panel.getLicensingPanel().setOptionalComponents(panel.getOptionalLicenses());
			panel.updateLicensing(status);
		}
	}

	// ===========================================================
	// Private constructor
	// ===========================================================

	private SimpleFingersApplication() {
	}
}
