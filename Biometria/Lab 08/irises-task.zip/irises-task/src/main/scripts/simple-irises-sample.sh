#!/bin/sh

java -jar simple-irises-sample.jar
