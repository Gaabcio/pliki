package com.neurotec.samples;

import com.neurotec.biometrics.*;
import com.neurotec.biometrics.client.NBiometricClient;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;

public final class MainPanel extends BasePanel {

    private static final long serialVersionUID = 1L;

    private DefaultTableModel tableModel;
    private JButton btnIdentify;
    private JLabel lblDirPath;
    private JLabel lblTemplatePath;

    // Szablony bazowe oraz szablon wybrany do identyfikacji
    private final ArrayList<File> baseSubjectsFiles = new ArrayList<>();
    private final ArrayList<NSubject> baseSubjects = new ArrayList<>();
    private NSubject subjectToIdentify;

    private int highlightIndex = -1;                     // indeks zaznaczonego wiersa

    static {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private JPanel panelIrisLeft;
    private JPanel panelIrisRight;

    // ===========================================================
    // Public constructor
    // ===========================================================

    public MainPanel() {
        super();
        licenses.add("Biometrics.IrisMatching");

        initGUI();
    }

    // ===========================================================
    // Private methods
    // ===========================================================

    protected void initGUI() {
        // Ustawiamy główny układ na BorderLayout
        this.setLayout(new BorderLayout());
        this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelLicensing = new LicensingPanel(licenses);
        add(panelLicensing, BorderLayout.NORTH);

        try {
            obtainLicenses(this);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(1, 2));
        add(mainPanel);

        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        {
            JPanel controlPanel = new JPanel();
            controlPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            controlPanel.setMinimumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
            leftPanel.add(controlPanel);
            {
                JLabel titleLabelLeft = new JLabel("Baza szablonów");
                titleLabelLeft.setFont(new Font("Arial", Font.BOLD, 14));
                controlPanel.add(titleLabelLeft);
                controlPanel.add(Box.createVerticalStrut(5));

                JButton btnOpenFolder = new JButton("Otwórz folder");
                btnOpenFolder.addActionListener(e -> handleLoadDatabase());
                controlPanel.add(btnOpenFolder);
                controlPanel.add(Box.createVerticalStrut(5));

                lblDirPath = new JLabel("Ścieżka folderu: Brak folderu");
                lblDirPath.setFont(new Font("Arial", Font.PLAIN, 9));
                controlPanel.add(lblDirPath);
            }

            // Tworzenie tabeli do wyświetlania plików
            JPanel templatesPanel = new JPanel();
            templatesPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
            leftPanel.add(templatesPanel);
            templatesPanel.setLayout(new BorderLayout());
            {
                tableModel = new DefaultTableModel(new Object[]{"Pliki szablonów (rozszerzenie .tp)", "Wynik dopasowania"}, 0);

                JTable table = new JTable(tableModel);
                table.setDefaultRenderer(Object.class, new HighlightRenderer());

                JScrollPane scrollPane = new JScrollPane(table);
                scrollPane.setPreferredSize(new Dimension(400, 200));
                templatesPanel.add(scrollPane, BorderLayout.CENTER);
            }

            // Panel z podglądem obrazu
            JPanel imagePanel = new JPanel();
            imagePanel.setBorder(BorderFactory.createTitledBorder("Szablon z najlepszym dopasowaniem"));
            imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.Y_AXIS));
            leftPanel.add(imagePanel);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
                imagePanel.add(scrollPane);

                panelIrisLeft = new JPanel();

                panelIrisLeft.setPreferredSize(new Dimension(400, 400));
                scrollPane.setViewportView(panelIrisLeft);
            }
        }


        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        {
            JPanel controlPanel = new JPanel();
            controlPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
            controlPanel.setMinimumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
            rightPanel.add(controlPanel);
            {
                JLabel titleLabelRight = new JLabel("Szablon do identyfikacji");
                titleLabelRight.setFont(new Font("Arial", Font.BOLD, 14));
                controlPanel.add(titleLabelRight);
                controlPanel.add(Box.createVerticalStrut(5));

                JButton btnSelectTemplate = new JButton("Wybierz szablon");
                btnSelectTemplate.addActionListener(e -> handleSelectTemplate());
                controlPanel.add(btnSelectTemplate);
                controlPanel.add(Box.createVerticalStrut(5));

                lblTemplatePath = new JLabel("Ścieżka szablonu: Brak wybranego szablonu");
                lblTemplatePath.setFont(new Font("Arial", Font.PLAIN, 9));
                controlPanel.add(lblTemplatePath); // Dodajemy etykietę do panelu prawego
                controlPanel.add(Box.createVerticalStrut(5));

                btnIdentify = new JButton("Identyfikuj");
                btnIdentify.setEnabled(false);
                btnIdentify.addActionListener(e -> handleIdentify());
                controlPanel.add(btnIdentify);
            }

            Box.Filler filler = new Box.Filler(new Dimension(0, 0), new Dimension(0, 177), new Dimension(Integer.MAX_VALUE, 177));
            rightPanel.add(filler);

            // Panel z podglądem obrazu
            JPanel imagePanel = new JPanel();
            imagePanel.setBorder(BorderFactory.createTitledBorder("Szablon do identyfikacji"));
            imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.Y_AXIS));
            rightPanel.add(imagePanel);
            {
                JScrollPane scrollPane = new JScrollPane();
                scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
                imagePanel.add(scrollPane);

                panelIrisRight = new JPanel();

                panelIrisRight.setPreferredSize(new Dimension(400, 400));
                scrollPane.setViewportView(panelIrisRight);
            }
        }


        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        setPreferredSize(new Dimension(1200, 900));
    }


    private void handleSelectTemplate() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Wybierz szablon");

        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int returnValue = fileChooser.showOpenDialog(this);

        lblTemplatePath.setForeground(Color.BLACK);
        if (returnValue != JFileChooser.APPROVE_OPTION) {

            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,
                    "Nie wybrano szablonu", "Uwaga",
                    JOptionPane.WARNING_MESSAGE));

            updateControls();
            return;
        }

        File selectedFile = fileChooser.getSelectedFile();
        if (!selectedFile.getName().endsWith(".tp")) {
            SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,
                    "Niepoprawny format: " + selectedFile.getName(), "Uwaga",
                    JOptionPane.WARNING_MESSAGE));

            updateControls();
            return;
        }

        File file = fileChooser.getSelectedFile();
        try {
            subjectToIdentify = NSubject.fromFile(file.getAbsolutePath());
            subjectToIdentify.setId(file.getName());

            lblTemplatePath.setText("Ścieżka szablonu: " + file.getAbsolutePath()); // Ustawienie ścieżki wybranego szablonu
        } catch (IOException e) {
            System.out.println(" Wczytanie szablonu " + file.getAbsolutePath() + " zakończyło się niepowodzeniem.");
        }


        updateControls();
    }

    // endregion utils
    private void handleIdentify() {
        if (subjectToIdentify == null) {
            return;
        }

        refreshDatabase(); // Ponowne wczytanie osobników z wybranych plików bazy.

        System.out.println("Szablon do identyfikacji: " + subjectToIdentify.getId());

        System.out.println("Lista dostępnych szablonów w bazie:");
        for (NSubject file : baseSubjects) {
            System.out.println(file.getId());
        }

    }

    private void handleLoadDatabase() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Wybierz folder");
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFolder = fileChooser.getSelectedFile();
            File[] tpFiles = selectedFolder.listFiles((dir, name) -> name.endsWith(".tp"));

            if (tpFiles != null) {
                // Wyczyszczenie tabeli
                baseSubjects.clear();
                baseSubjectsFiles.clear();
                tableModel.setRowCount(0);

                // Zaktualizowanie tableli
                for (File tpFile : tpFiles) {
                    baseSubjectsFiles.add(tpFile);
                    tableModel.addRow(new Object[]{tpFile.getName()});
                }
                lblDirPath.setText("Ścieżka folderu: " + selectedFolder.getAbsolutePath());
            } else {
                JOptionPane.showMessageDialog(this, "Brak plików .tp w tym folderze.", "Brak plików", JOptionPane.INFORMATION_MESSAGE);
                lblDirPath.setText("Ścieżka folderu: Brak plików .tp");
            }
        }

        updateControls();
    }

    /**
     * Ponownie wczytuje szablony dla wszystkich plików
     */
    private void refreshDatabase() {
        baseSubjects.clear();
        for (File subjectFile : baseSubjectsFiles) {
            ArrayList<String> failedList = new ArrayList<>();
            try {
                NSubject s = NSubject.fromFile(subjectFile.getAbsolutePath());
                s.setId(subjectFile.getName());
                baseSubjects.add(s);
            } catch (IOException e) {
                failedList.add(subjectFile.getAbsolutePath());
            }

            if (!failedList.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (String path : failedList) sb.append(path).append("\n");
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,
                        "Nie wczytano następujacych szablonów: \n" + sb, "Error",
                        JOptionPane.WARNING_MESSAGE));
            }
        }

        updateControls();
    }


    // region TableCellRenderer

    /**
     * Podświetla wiesz na zadanym indeksie. Wywołanie z wartością -1 lub jakąkolwiek spoza przedziału
     * skutkuje odznaczeniem wierszy.
     *
     * @param index - indeks wiersza do podświetlenia
     */
    private void highlight(int index) {

        highlightIndex = index;
        tableModel.fireTableDataChanged();  // Odświeżamy tabelę, aby zaktualizować widok
    }

    private class HighlightRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if (row == highlightIndex) {
                component.setBackground(Color.GREEN);
            } else {
                component.setBackground(Color.WHITE);
            }

            return component;
        }
    }
    // endregion TableCellRenderer

    @Override
    protected void setDefaultValues() {

    }

    @Override
    protected void updateControls() {
        btnIdentify.setEnabled(!this.baseSubjectsFiles.isEmpty() && this.subjectToIdentify != null);
    }

    @Override
    protected void updateIrisesTools() {

    }

    // ===========================================================
    // Public methods
    // ===========================================================

    public void obtainLicenses(BasePanel panel) throws IOException {
        if (!panel.isObtained()) {
            boolean status = IrisesTools.getInstance().obtainLicenses(panel.getLicenses());
            panel.updateLicensing(status);
        }
    }
}
